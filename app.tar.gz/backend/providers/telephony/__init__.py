from .mock import MockTelephonyProvider
